@echo off
chcp 65001 > nul
echo 로컬 Qwen3 4B 모델 설치를 시작합니다.
where ollama >nul 2>nul
if errorlevel 1 (
  echo Ollama가 설치되어 있지 않습니다.
  echo https://ollama.com/download 에서 Ollama를 먼저 설치해 주세요.
  pause
  exit /b 1
)
ollama pull qwen3:4b
if errorlevel 1 (
  echo Qwen3 설치 중 오류가 발생했습니다.
  pause
  exit /b 1
)
echo Qwen3 4B 설치가 완료되었습니다.
pause
