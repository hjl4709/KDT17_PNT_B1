param([switch]$NoBrowser)

$ErrorActionPreference = "Stop"
$appRoot = [System.IO.Path]::GetFullPath($PSScriptRoot)
$listener = $null

function Get-FreePort {
    $probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
    try { $probe.Start(); return ([System.Net.IPEndPoint]$probe.LocalEndpoint).Port }
    finally { $probe.Stop() }
}

function Get-ContentType([string]$path) {
    switch ([System.IO.Path]::GetExtension($path).ToLowerInvariant()) {
        ".html" { "text/html; charset=utf-8" }
        ".css" { "text/css; charset=utf-8" }
        ".js" { "text/javascript; charset=utf-8" }
        ".json" { "application/json; charset=utf-8" }
        ".svg" { "image/svg+xml" }
        ".txt" { "text/plain; charset=utf-8" }
        ".md" { "text/markdown; charset=utf-8" }
        ".xlsx" { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }
        default { "application/octet-stream" }
    }
}

function Write-Response($stream,[int]$status,[string]$statusText,[string]$contentType,[byte[]]$body,[bool]$headOnly=$false) {
    $headers = "HTTP/1.1 $status $statusText`r`nContent-Type: $contentType`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
    $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($headers)
    $stream.Write($headerBytes,0,$headerBytes.Length)
    if(-not $headOnly -and $body.Length){$stream.Write($body,0,$body.Length)}
    $stream.Flush()
}

try {
    $port = Get-FreePort
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback,$port)
    $listener.Start()
    $url = "http://127.0.0.1:$port/"
    Write-Host ""
    Write-Host "Report Draft AI is running." -ForegroundColor Cyan
    Write-Host "Browser address: $url"
    Write-Host "Keep this window open while using the app."
    Write-Host ""
    if(-not $NoBrowser){Start-Process -FilePath $url}
    while($true){
        $client=$listener.AcceptTcpClient()
        try{
            $stream=$client.GetStream()
            $reader=[System.IO.StreamReader]::new($stream,[System.Text.Encoding]::ASCII,$false,4096,$true)
            $requestLine=$reader.ReadLine()
            if([string]::IsNullOrWhiteSpace($requestLine)){continue}
            while($true){$line=$reader.ReadLine();if($null -eq $line -or $line.Length -eq 0){break}}
            $parts=$requestLine.Split(' ')
            if($parts.Length -lt 2){Write-Response $stream 400 "Bad Request" "text/plain" ([Text.Encoding]::UTF8.GetBytes("Bad request."));continue}
            $method=$parts[0].ToUpperInvariant();$headOnly=$method -eq "HEAD"
            if($method -ne "GET" -and -not $headOnly){Write-Response $stream 405 "Method Not Allowed" "text/plain" ([Text.Encoding]::UTF8.GetBytes("Method not allowed."));continue}
            $relative=[Uri]::UnescapeDataString($parts[1].Split('?')[0].TrimStart('/'))
            if([string]::IsNullOrWhiteSpace($relative)){$relative="index.html"}
            $relative=$relative.Replace('/',[IO.Path]::DirectorySeparatorChar)
            $fullPath=[IO.Path]::GetFullPath((Join-Path $appRoot $relative))
            $prefix=$appRoot.TrimEnd([IO.Path]::DirectorySeparatorChar)+[IO.Path]::DirectorySeparatorChar
            if(-not $fullPath.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){Write-Response $stream 403 "Forbidden" "text/plain" ([Text.Encoding]::UTF8.GetBytes("Forbidden.")) $headOnly;continue}
            if(Test-Path -LiteralPath $fullPath -PathType Leaf){$body=[IO.File]::ReadAllBytes($fullPath);Write-Response $stream 200 "OK" (Get-ContentType $fullPath) $body $headOnly}
            else{Write-Response $stream 404 "Not Found" "text/plain" ([Text.Encoding]::UTF8.GetBytes("Not found.")) $headOnly}
        }catch{try{Write-Response $stream 500 "Internal Server Error" "text/plain" ([Text.Encoding]::UTF8.GetBytes("Server error."))}catch{}}
        finally{$client.Close()}
    }
}catch{
    Write-Host "Launch error: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Close other app windows and try again."
    exit 1
}finally{if($null -ne $listener){$listener.Stop()}}
