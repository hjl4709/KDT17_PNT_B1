(function(root){
'use strict';

const text=value=>value===null||value===undefined?'':String(value).trim();
const cleanLines=value=>text(value).split(/\r?\n/).map(line=>line.trim()).filter(Boolean);
const today=()=>new Date().toISOString().slice(0,10);
const uid=(prefix='RPT')=>`${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;

const FORMAT={
 meeting:{name:'회의록',sections:['회의 개요','주요 논의','결정사항','조치사항','확인 필요']},
 weekly:{name:'주간업무보고',sections:['보고 개요','금주 주요 실적','지연 및 위험','차주 계획','지원 요청']},
 executive:{name:'경영진 요약보고',sections:['핵심 요약','주요 성과','핵심 위험','의사결정 요청','다음 계획']},
 customer:{name:'고객 진행보고',sections:['프로젝트 현황','완료 사항','진행 사항','이슈 및 대응','향후 일정']}
};
const TONE={concise:'간결한 업무체',polite:'정중한 보고체',formal:'공식 문서체'};
const LENGTH={short:'짧게',standard:'보통',detail:'자세하게'};
const AUDIENCE={worker:'실무자',manager:'팀장·PM',executive:'경영진·고객'};

function stripCodeFence(value){
 const raw=text(value).replace(/<think>[\s\S]*?<\/think>/gi,'').replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'').trim();
 const first=raw.indexOf('{'),last=raw.lastIndexOf('}');
 return first>=0&&last>first?raw.slice(first,last+1):raw;
}
function parseModelResponse(value){return value&&typeof value==='object'?value:JSON.parse(stripCodeFence(value));}

function dateFromLine(line){
 const iso=line.match(/(20\d{2})[.\/-](\d{1,2})[.\/-](\d{1,2})/);
 if(iso)return`${iso[1]}-${iso[2].padStart(2,'0')}-${iso[3].padStart(2,'0')}`;
 const md=line.match(/(?:기한|까지|완료|회신)[^0-9]{0,8}(\d{1,2})[.\/-](\d{1,2})/);
 if(md)return`${new Date().getFullYear()}-${md[1].padStart(2,'0')}-${md[2].padStart(2,'0')}`;
 return'';
}
function ownerFromLine(line){
 let match=line.match(/(?:담당(?:자)?|오너|책임)\s*[:：-]\s*([가-힣A-Za-z0-9_ -]{2,18})/);
 if(match)return match[1].split(/[,/|]/)[0].trim();
 match=line.match(/([가-힣A-Za-z]{2,8}(?:\s+[가-힣A-Za-z]{2,8})?)이\s+20\d{2}[.\/-]/);
 if(match)return match[1].trim();
 match=line.match(/^[-*•\d.)\s]*([가-힣]{2,5}(?:팀|부|실|파트|PM)?)(?:은|는|이|가)\s/);
 return match?match[1]:'';
}
function extractActions(source){
 const keywords=['하기로','조치','확인','검토','작성','공유','제출','요청','대응','수정','발주','점검','협의','준비','필요','추적','확정'];
 return cleanLines(source).filter(line=>keywords.some(key=>line.includes(key))).slice(0,15).map((line,index)=>({
  id:`ACT-${String(index+1).padStart(3,'0')}`,task:line.replace(/^[-*•\d.)\s]+/,'').slice(0,180),owner:ownerFromLine(line),due:dateFromLine(line),status:'예정',evidence:line.slice(0,220)
 }));
}

function normalizeAction(action,index){return{
 id:text(action?.id)||`ACT-${String(index+1).padStart(3,'0')}`,
 task:text(action?.task||action?.action||action?.조치사항).slice(0,220),
 owner:text(action?.owner||action?.assignee||action?.담당자).slice(0,60),
 due:text(action?.due||action?.deadline||action?.기한).slice(0,10),
 status:text(action?.status||action?.상태)||'예정',
 evidence:text(action?.evidence||action?.근거).slice(0,260)
};}
function normalizeDraft(raw,input,engine='qwen3'){
 const actions=(raw?.actions||raw?.action_items||raw?.조치사항||[]).map(normalizeAction).filter(item=>item.task);
 return{
  id:uid(),createdAt:new Date().toISOString(),engine,format:input.format||'weekly',project:text(input.project),date:text(input.date)||today(),tone:input.tone,length:input.length,audience:input.audience,request:text(input.request),
  title:text(raw?.title)||`${text(input.project)||'프로젝트'} ${FORMAT[input.format]?.name||'보고서'}`,
  summary:text(raw?.summary||raw?.report_text||raw?.body||raw?.보고서)||'생성된 본문이 없습니다.',
  uncertainties:Array.isArray(raw?.uncertainties)?raw.uncertainties.map(text).filter(Boolean):[],actions,sourceFiles:[...(input.sourceFiles||[])],sourceExcerpt:text(input.sourceText).slice(0,2600)
 };
}

function fallbackDraft(input){
 const lines=cleanLines(input.sourceText).map(line=>line.replace(/^[-*•\d.)\s]+/,'')).filter(line=>line.length>2);
 const decisions=lines.filter(line=>/결정|확정|승인|합의|완료/.test(line));
 const risks=lines.filter(line=>/위험|문제|지연|이슈|우려|미정|대기|초과|필요/.test(line));
 const plans=lines.filter(line=>/차주|예정|계획|까지|진행|조치|확인/.test(line));
 const size=input.length==='short'?4:input.length==='detail'?12:7;
 const format=FORMAT[input.format]||FORMAT.weekly;
 const blocks={
  meeting:[['회의 개요',[`${input.project||'프로젝트'} / ${input.date||today()}`]],['주요 논의',lines.slice(0,size)],['결정사항',decisions.slice(0,size)],['확인 필요',risks.slice(0,size)]],
  weekly:[['보고 개요',[`${input.project||'프로젝트'} / 기준일 ${input.date||today()}`]],['금주 주요 실적',decisions.slice(0,size)],['지연 및 위험',risks.slice(0,size)],['차주 계획',plans.slice(0,size)]],
  executive:[['핵심 요약',lines.slice(0,3)],['주요 성과',decisions.slice(0,size)],['핵심 위험',risks.slice(0,size)],['의사결정 요청',plans.slice(0,4)]],
  customer:[['프로젝트 현황',lines.slice(0,4)],['완료 사항',decisions.slice(0,size)],['진행 사항',plans.slice(0,size)],['이슈 및 대응',risks.slice(0,size)]]
 };
 const summary=(blocks[input.format]||blocks.weekly).map(([heading,items])=>`${heading}\n${(items.length?items:['입력 자료에서 확인된 내용이 없습니다.']).map(item=>`- ${item}`).join('\n')}`).join('\n\n');
 const uncertainties=[];
 if(!input.sourceText.trim())uncertainties.push('입력 자료가 없습니다.');
 if(extractActions(input.sourceText).some(item=>!item.owner||!item.due))uncertainties.push('일부 조치사항의 담당자 또는 기한을 확인해야 합니다.');
 uncertainties.push('로컬 Qwen3에 연결되지 않아 규칙 기반 초안을 만들었습니다.');
 return normalizeDraft({title:`${input.project||'프로젝트'} ${format.name}`,summary,actions:extractActions(input.sourceText),uncertainties},input,'rule');
}

function buildPrompt(input){
 const format=FORMAT[input.format]||FORMAT.weekly;
 return[
  '너는 제조장비 기업 내부에서 사용하는 보고서 초안 작성 AI다.',
  `입력 자료만 근거로 표준 ${format.name} 초안을 작성한다.`,
  `필수 구성: ${format.sections.join(', ')}`,
  `문장 톤: ${TONE[input.tone]||TONE.polite}`,
  `분량: ${LENGTH[input.length]||LENGTH.standard}`,
  `보고 대상: ${AUDIENCE[input.audience]||AUDIENCE.manager}`,
  input.request?`사용자 추가 요청: ${input.request}`:'사용자 추가 요청: 없음',
  '입력에 없는 사실, 원인, 담당자, 날짜, 수치를 만들지 않는다.',
  '담당자나 기한이 없으면 빈 문자열로 두고 uncertainties에 확인 필요 항목을 적는다.',
  '조치사항은 task, owner, due, status, evidence로 분리한다.',
  'JSON 외의 문장을 출력하지 않는다.',
  '출력 JSON:',
  JSON.stringify({title:'보고서 제목',summary:'표준 양식의 편집 가능한 전체 본문',uncertainties:['확인 필요 사항'],actions:[{task:'조치사항',owner:'담당자 또는 빈 값',due:'YYYY-MM-DD 또는 빈 값',status:'예정',evidence:'입력 근거'}]}),
  '문서 정보:',JSON.stringify({project:input.project,date:input.date,format:format.name,tone:TONE[input.tone],length:LENGTH[input.length],audience:AUDIENCE[input.audience],sourceFiles:input.sourceFiles||[]}),
  '입력 자료:',text(input.sourceText).slice(0,30000)
 ].join('\n');
}

root.ReportAI={FORMAT,TONE,LENGTH,AUDIENCE,parseModelResponse,extractActions,normalizeDraft,fallbackDraft,buildPrompt,today,uid};
if(typeof module!=='undefined')module.exports=root.ReportAI;
})(globalThis);
