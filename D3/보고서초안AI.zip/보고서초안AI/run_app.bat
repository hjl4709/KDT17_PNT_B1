@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0start_app.ps1" (
  echo ERROR: Required files are missing.
  echo Extract the entire ZIP file first, then run this file again.
  pause
  exit /b 1
)
echo Starting Report Draft AI...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_app.ps1"
if errorlevel 1 (
  echo.
  echo ERROR: The app could not start.
  echo See the message above, then try RUN_APP.cmd.
  pause
)
endlocal
